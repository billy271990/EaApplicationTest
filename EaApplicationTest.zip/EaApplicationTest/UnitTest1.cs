﻿using System;
using EAFramework.Config;
using EAFramework.Driver;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using Xunit;

namespace EaApplicationTest
{
    public class UnitTest1 : IDisposable, IDriverFixture
    {
        
        private IDriverFixture _driverFixture;

        public UnitTest1()
        {
            var testSettings = new TestSettings
            {
                BrowserType = DriverFixture.BrowserType.Chrome,
                ApplicationUrl = new Uri("http://localhost:8000"),
                TimeoutInternal = 30
            };

            _driverFixture = new DriverFixture(testSettings);
        }

        [Fact]
        public void Test1()
        {
            IWebDriver driver = new ChromeDriver();
            _driverFixture.Driver.FindElement(By.LinkText("Product")).Click();
            _driverFixture.Driver.FindElement(By.LinkText("Create")).Click();
            _driverFixture.Driver.FindElement(By.Id("Name")).SendKeys("New Product");
            _driverFixture.Driver.FindElement(By.Id("Description")).SendKeys("New Description");
            
            _driverFixture.Driver.FindElement(By.Id("Price")).SendKeys("10000");
            var productType = driver.FindElement(By.Id("ProductType"));
            SelectElement select = new SelectElement(productType);
            select.SelectByText("CPU");
            _driverFixture.Driver.FindElement(By.Id("Create")).Submit();
        }

        public void Dispose()
        {
            _driverFixture.Driver?.Quit();
        }
    }
}
