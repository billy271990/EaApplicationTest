﻿using System;

namespace EAFramework
{
    public class Class1
    {
    }
}
